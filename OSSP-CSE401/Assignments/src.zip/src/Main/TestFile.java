package Main;

import tasks.NewFile;

public class TestFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewFile nf = new NewFile();
		nf.create("Folder/f");
	}

}
