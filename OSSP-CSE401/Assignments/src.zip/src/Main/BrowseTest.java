package Main;

import tasks.Browse;

public class BrowseTest {
	public static void main(String[] args) {
		Browse browser = new Browse();
		browser.open("www.google.com");
	}
}
