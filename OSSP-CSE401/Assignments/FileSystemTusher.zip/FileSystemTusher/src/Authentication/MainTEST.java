package Authentication;

public class MainTEST {
	public static void main(String[] args) {
		FirstLogInPage firstLogInPage = new FirstLogInPage();
		firstLogInPage.runPage();
	}
}
