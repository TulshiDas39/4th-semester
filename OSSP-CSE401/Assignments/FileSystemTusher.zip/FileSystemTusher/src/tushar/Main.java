package tushar;
import java.io.FileNotFoundException;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		//FileWindow cd = new FileWindow("Alluser","AllUser");
		//FileTreeFrame tre = new FileTreeFrame("Atiq");
	}

}
  